package com.capgemini.test;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.capgemini.exceptions.InsufficientBalanceException;
import com.capgemini.exceptions.InsufficientInitialAmountException;
import com.capgemini.exceptions.InvalidAccountNumberException;
import com.capgemini.model.Account;
import com.capgemini.repository.AccountRepository;
import com.capgemini.service.AccountService;
import com.capgemini.service.AccountServiceImpl;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

public class AccountTest {

	AccountService accountService;
	@Mock
	AccountRepository accountRepository;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);

		accountService = new AccountServiceImpl(accountRepository);

	}

	/*
	 * create account 1.when the amount is less than 500 then system should throw
	 * exception 2.when the valid info is passed account should be created
	 * successfully
	 */

	@Test(expected = com.capgemini.exceptions.InsufficientInitialAmountException.class)
	public void whenTheAmountIsLessThan500SystemShouldThrowException() throws InsufficientInitialAmountException {
		accountService.createAccount(101, 400);
	}

	@Test
	public void whenTheValidInfoIsPassedAccountShouldBeCreatedSuccessfully() throws InsufficientInitialAmountException {
		Account account = new Account();
		account.setAccountNumber(101);
		account.setAmount(5000);
		when(accountRepository.save(account)).thenReturn(true);
		assertEquals(account, accountService.createAccount(101, 5000));
	}

	@Test
	public void whenValidAccountNumberIsPassesGivenAmountShouldBedeposited() throws InvalidAccountNumberException, InsufficientInitialAmountException {

		Account account1 = new Account();
		account1.setAccountNumber(201);
		account1.setAmount(2000);
		when(accountRepository.searchAccount(201)).thenReturn(account1);
		accountService.depositAmount(account1.getAccountNumber(), 1000);
		assertEquals(account1.getAmount(), 3000);
	}

	@Test(expected = InvalidAccountNumberException.class)
	public void whenInValidAccountNumberIsPassedInvalidAccountNumberExceptionmustbeThrown() throws InsufficientInitialAmountException, InvalidAccountNumberException {
		accountService.depositAmount(111, 1000);

	}

	@Test
	public void whenValidInfoIsPassesGivenAmountShouldBeWithdrawn()
			throws InsufficientInitialAmountException, InvalidAccountNumberException, InsufficientBalanceException {
		Account account1 = new Account();
		account1.setAccountNumber(201);
		account1.setAmount(2000);
		when(accountRepository.searchAccount(201)).thenReturn(account1);
		accountService.withdrawAmount(account1.getAccountNumber(), 100);
		assertEquals(account1.getAmount(), 1900);

	}

	@Test(expected = InvalidAccountNumberException.class)
	public void whenInvalidInfoIsPassedInvalidAccountNumberExceptionShouldBeRaised()
			throws InsufficientInitialAmountException, InvalidAccountNumberException, InsufficientBalanceException {
		accountService.withdrawAmount(111, 2500);

	}

	@Test(expected = InsufficientBalanceException.class)
	public void whenInvalidAmountIsPassedInsufficientBalanceExceptionShouldBeRaised()
			throws InsufficientInitialAmountException, InvalidAccountNumberException, InsufficientBalanceException {
		Account account1 = new Account();
		account1.setAccountNumber(201);
		account1.setAmount(2000);
		when(accountRepository.searchAccount(201)).thenReturn(account1);
		accountService.withdrawAmount(account1.getAccountNumber(), 3000);
	}

}
